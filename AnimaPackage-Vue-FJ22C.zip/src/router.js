import Vue from "vue";
import Router from "vue-router";
import IndiMobile375 from "./components/IndiMobile375";
import IndiDesktop1440 from "./components/IndiDesktop1440";
import IndiTablet768 from "./components/IndiTablet768";
import { indiMobile375Data, indiDesktop1440Data, indiTablet768Data } from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/full-project",
      component: IndiMobile375,
      props: {
        property1heroMobileProps: indiMobile375Data.property1heroMobileProps,
        property1filmGridMobile1Props: indiMobile375Data.property1filmGridMobile1Props,
        property1filmGridMobile2Props: indiMobile375Data.property1filmGridMobile2Props,
        property1containerPromoMobileProps: indiMobile375Data.property1containerPromoMobileProps,
      },
    },
    {
      path: "/indi-tablet-768",
      component: IndiTablet768,
      props: {
        property1heroTabletProps: indiTablet768Data.property1heroTabletProps,
        filmGridTablet1Props: indiTablet768Data.filmGridTablet1Props,
        filmGridTablet2Props: indiTablet768Data.filmGridTablet2Props,
        property1containerPromoTabletProps: indiTablet768Data.property1containerPromoTabletProps,
      },
    },
    {
      path: "*",
      component: IndiDesktop1440,
      props: {
        property1heroDesktopProps: indiDesktop1440Data.property1heroDesktopProps,
        property1filmGridDesktop1Props: indiDesktop1440Data.property1filmGridDesktop1Props,
        property1filmGridDesktop2Props: indiDesktop1440Data.property1filmGridDesktop2Props,
        property1containerPromoDesktopProps: indiDesktop1440Data.property1containerPromoDesktopProps,
      },
    },
  ],
});
