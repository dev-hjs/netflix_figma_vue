export const property1btnWatchMobileData = {
    btnWatch: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/btn-watch@2x.png",
    watchNow: "Watch Now",
};

export const property1heroMobileData = {
    filmPreview: "https://cdn.animaapp.com/projects/6202849b5e1915b58277544f/files/trailer-m-1-cut-1.webp",
    indiLogo: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/indi-logo@2x.png",
    title: "SAM AWAY",
    filmInfo: "Adventure, Fantasy  |  2019  |  136 Min.",
    filmAbout: "When a tornado hits through City of Peaceville,<br />Samantha (Jenny Loifer) and her dog, Ricko, <br />are whisked away in their house to an amazing journey.",
    filmCredits: "Director: Todd Burns<br />Cast: Jenny Loifer, Sarah Obrien, Larry Moss Jr.",
    property1btnWatchMobileProps: property1btnWatchMobileData,
};

export const filmThumbMobile1Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb@2x.png",
};

export const filmThumbMobile2Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-1@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile3Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-6@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile4Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-7@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile5Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-2@2x.png",
    className: "film-thumb-2",
};

export const filmThumbMobile6Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-3@2x.png",
    className: "film-thumb-3",
};

export const filmThumbMobile7Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-8@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile8Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-10@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile9Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-4@2x.png",
};

export const filmThumbMobile10Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-5@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile11Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-9@2x.png",
    className: "film-thumb-4",
};

export const filmThumbMobile12Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-11@2x.png",
    className: "film-thumb-4",
};

export const property1filmGridMobile1Data = {
    title: "Recently Added Films",
    filmThumbMobile1Props: filmThumbMobile1Data,
    filmThumbMobile2Props: filmThumbMobile2Data,
    filmThumbMobile3Props: filmThumbMobile3Data,
    filmThumbMobile4Props: filmThumbMobile4Data,
    filmThumbMobile5Props: filmThumbMobile5Data,
    filmThumbMobile6Props: filmThumbMobile6Data,
    filmThumbMobile7Props: filmThumbMobile7Data,
    filmThumbMobile8Props: filmThumbMobile8Data,
    filmThumbMobile9Props: filmThumbMobile9Data,
    filmThumbMobile10Props: filmThumbMobile10Data,
    filmThumbMobile11Props: filmThumbMobile11Data,
    filmThumbMobile12Props: filmThumbMobile12Data,
};

export const filmThumbMobile13Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-12@2x.png",
};

export const filmThumbMobile14Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-13@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile15Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-18@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile16Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-19@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile17Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-14@2x.png",
    className: "film-thumb-2",
};

export const filmThumbMobile18Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-15@2x.png",
    className: "film-thumb-3",
};

export const filmThumbMobile19Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-20@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile20Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-22@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile21Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-16@2x.png",
};

export const filmThumbMobile22Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-17@2x.png",
    className: "film-thumb-1",
};

export const filmThumbMobile23Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-21@2x.png",
    className: "film-thumb-4",
};

export const filmThumbMobile24Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-23@2x.png",
    className: "film-thumb-4",
};

export const property1filmGridMobile2Data = {
    title: "Top Rated Films",
    filmThumbMobile1Props: filmThumbMobile13Data,
    filmThumbMobile2Props: filmThumbMobile14Data,
    filmThumbMobile3Props: filmThumbMobile15Data,
    filmThumbMobile4Props: filmThumbMobile16Data,
    filmThumbMobile5Props: filmThumbMobile17Data,
    filmThumbMobile6Props: filmThumbMobile18Data,
    filmThumbMobile7Props: filmThumbMobile19Data,
    filmThumbMobile8Props: filmThumbMobile20Data,
    filmThumbMobile9Props: filmThumbMobile21Data,
    filmThumbMobile10Props: filmThumbMobile22Data,
    filmThumbMobile11Props: filmThumbMobile23Data,
    filmThumbMobile12Props: filmThumbMobile24Data,
};

export const property1containerPromoMobileData = {
    containerPromotion: "https://media.giphy.com/media/l6mBchxYZc7Sw/giphy.gif",
    title: "Stay Connected",
    paragraph: "From cult classics to modern masterpieces.<br />Stay updated with the latest movies, news and articles from INDI.",
    inputType: "email",
    inputPlaceholder: "Your Email",
};

export const indiMobile375Data = {
    property1heroMobileProps: property1heroMobileData,
    property1filmGridMobile1Props: property1filmGridMobile1Data,
    property1filmGridMobile2Props: property1filmGridMobile2Data,
    property1containerPromoMobileProps: property1containerPromoMobileData,
};

export const property1btnWatchDesktopData = {
    btnWatch: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/btn-watch-1@2x.png",
    watchNow: "Watch Now",
};

export const property1heroDesktopData = {
    heroContainer: "https://cdn.animaapp.com/projects/6202849b5e1915b58277544f/files/trailer-m-1-cut-1.webp",
    mainTitle: "SAM AWAY",
    filmInfo: "Adventure, Fantasy  |  2019  |  136 Min.",
    filmAbout: "When a tornado hits through City of Peaceville,<br />Samantha (Jenny Loifer) and her dog, Ricko, <br />are whisked away in their house to an amazing journey.",
    filmCredits: "Director: Todd Burns<br />Cast: Jenny Loifer, Sarah Obrien, Larry Moss Jr.",
    property1btnWatchDesktopProps: property1btnWatchDesktopData,
};

export const filmThumbDesktop1Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-36@2x.png",
};

export const filmThumbDesktop2Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-37@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop3Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-38@2x.png",
};

export const filmThumbDesktop4Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-39@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop5Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-40@2x.png",
};

export const filmThumbDesktop6Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-41@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop7Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-42@2x.png",
};

export const filmThumbDesktop8Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-43@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop9Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-44@2x.png",
};

export const filmThumbDesktop10Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-46@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop11Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-45@2x.png",
};

export const filmThumbDesktop12Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-47@2x.png",
    className: "film-thumb-7",
};

export const property1filmGridDesktop1Data = {
    sectionTitle: "Recently Added Films",
    filmThumbDesktop1Props: filmThumbDesktop1Data,
    filmThumbDesktop2Props: filmThumbDesktop2Data,
    filmThumbDesktop3Props: filmThumbDesktop3Data,
    filmThumbDesktop4Props: filmThumbDesktop4Data,
    filmThumbDesktop5Props: filmThumbDesktop5Data,
    filmThumbDesktop6Props: filmThumbDesktop6Data,
    filmThumbDesktop7Props: filmThumbDesktop7Data,
    filmThumbDesktop8Props: filmThumbDesktop8Data,
    filmThumbDesktop9Props: filmThumbDesktop9Data,
    filmThumbDesktop10Props: filmThumbDesktop10Data,
    filmThumbDesktop11Props: filmThumbDesktop11Data,
    filmThumbDesktop12Props: filmThumbDesktop12Data,
};

export const filmThumbDesktop13Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-24@2x.png",
};

export const filmThumbDesktop14Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-25@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop15Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-26@2x.png",
};

export const filmThumbDesktop16Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-27@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop17Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-28@2x.png",
};

export const filmThumbDesktop18Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-29@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop19Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-30@2x.png",
};

export const filmThumbDesktop20Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-31@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop21Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-32@2x.png",
};

export const filmThumbDesktop22Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-34@2x.png",
    className: "film-thumb-7",
};

export const filmThumbDesktop23Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-33@2x.png",
};

export const filmThumbDesktop24Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-35@2x.png",
    className: "film-thumb-7",
};

export const property1filmGridDesktop2Data = {
    sectionTitle: "Top Rated Films",
    className: "container-films-1-2",
    filmThumbDesktop1Props: filmThumbDesktop13Data,
    filmThumbDesktop2Props: filmThumbDesktop14Data,
    filmThumbDesktop3Props: filmThumbDesktop15Data,
    filmThumbDesktop4Props: filmThumbDesktop16Data,
    filmThumbDesktop5Props: filmThumbDesktop17Data,
    filmThumbDesktop6Props: filmThumbDesktop18Data,
    filmThumbDesktop7Props: filmThumbDesktop19Data,
    filmThumbDesktop8Props: filmThumbDesktop20Data,
    filmThumbDesktop9Props: filmThumbDesktop21Data,
    filmThumbDesktop10Props: filmThumbDesktop22Data,
    filmThumbDesktop11Props: filmThumbDesktop23Data,
    filmThumbDesktop12Props: filmThumbDesktop24Data,
};

export const property1btnSubmitDesktop2Data = {
    className: "btn-submit-1",
};

export const property1containerPromoDesktopData = {
    title: "Stay Connected",
    paragraph: "From cult classics to modern masterpieces.<br />Stay updated with the latest movies, news and articles from INDI.",
    inputType: "email",
    inputPlaceholder: "Your Email",
    gifCinema: "https://media.giphy.com/media/l6mBchxYZc7Sw/giphy.gif",
    property1btnSubmitDesktopProps: property1btnSubmitDesktop2Data,
};

export const indiDesktop1440Data = {
    property1heroDesktopProps: property1heroDesktopData,
    property1filmGridDesktop1Props: property1filmGridDesktop1Data,
    property1filmGridDesktop2Props: property1filmGridDesktop2Data,
    property1containerPromoDesktopProps: property1containerPromoDesktopData,
};

export const property1btnWatchTabletData = {
    btnWatch: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/btn-watch-2@2x.png",
    watchNow: "Watch Now",
};

export const property1heroTabletData = {
    heroContainer: "https://cdn.animaapp.com/projects/6202849b5e1915b58277544f/files/trailer-m-1-cut-1.webp",
    title: "SAM AWAY",
    filmInfo: "Adventure, Fantasy  |  2019  |  136 Min.",
    filmAbout: "When a tornado hits through City of Peaceville,<br />Samantha (Jenny Loifer) and her dog, Ricko, <br />are whisked away in their house to an amazing journey.",
    filmCredits: "Director: Todd Burns<br />Cast: Jenny Loifer, Sarah Obrien, Larry Moss Jr.",
    property1btnWatchTabletProps: property1btnWatchTabletData,
};

export const filmThumbTablet1Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-48@2x.png",
};

export const filmThumbTablet2Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-49@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet3Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-50@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet4Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-51@2x.png",
    className: "film-thumb-10",
};

export const filmThumbTablet5Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-52@2x.png",
};

export const filmThumbTablet6Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-53@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet7Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-54@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet8Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-55@2x.png",
    className: "film-thumb-10",
};

export const filmThumbTablet9Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-56@2x.png",
    className: "film-thumb-11",
};

export const filmThumbTablet10Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-57@2x.png",
    className: "film-thumb-12",
};

export const filmThumbTablet11Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-58@2x.png",
    className: "film-thumb-12",
};

export const filmThumbTablet12Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-59@2x.png",
    className: "film-thumb-13",
};

export const filmGridTablet1Data = {
    sectionTitle: "Recently Added Films",
    rowProps: filmThumbTablet1Data,
    rowProps2: filmThumbTablet2Data,
    rowProps3: filmThumbTablet3Data,
    rowProps4: filmThumbTablet4Data,
    rowProps5: filmThumbTablet5Data,
    rowProps6: filmThumbTablet6Data,
    rowProps7: filmThumbTablet7Data,
    rowProps8: filmThumbTablet8Data,
    rowProps9: filmThumbTablet9Data,
    rowProps10: filmThumbTablet10Data,
    rowProps11: filmThumbTablet11Data,
    rowProps12: filmThumbTablet12Data,
};

export const filmThumbTablet13Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-60@2x.png",
};

export const filmThumbTablet14Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-61@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet15Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-62@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet16Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-63@2x.png",
    className: "film-thumb-10",
};

export const filmThumbTablet17Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-64@2x.png",
};

export const filmThumbTablet18Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-65@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet19Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-66@2x.png",
    className: "film-thumb-9",
};

export const filmThumbTablet20Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-67@2x.png",
    className: "film-thumb-10",
};

export const filmThumbTablet21Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-68@2x.png",
    className: "film-thumb-11",
};

export const filmThumbTablet22Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-69@2x.png",
    className: "film-thumb-12",
};

export const filmThumbTablet23Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-70@2x.png",
    className: "film-thumb-12",
};

export const filmThumbTablet24Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/film-thumb-71@2x.png",
    className: "film-thumb-13",
};

export const filmGridTablet2Data = {
    sectionTitle: "Top Rated Films",
    rowProps: filmThumbTablet13Data,
    rowProps2: filmThumbTablet14Data,
    rowProps3: filmThumbTablet15Data,
    rowProps4: filmThumbTablet16Data,
    rowProps5: filmThumbTablet17Data,
    rowProps6: filmThumbTablet18Data,
    rowProps7: filmThumbTablet19Data,
    rowProps8: filmThumbTablet20Data,
    rowProps9: filmThumbTablet21Data,
    rowProps10: filmThumbTablet22Data,
    rowProps11: filmThumbTablet23Data,
    rowProps12: filmThumbTablet24Data,
};

export const property1btnSubmitDesktop3Data = {
    className: "btn-submit-2",
};

export const property1containerPromoTabletData = {
    title: "Stay Connected",
    paragraph: "From cult classics to modern masterpieces.<br />Stay updated with the latest movies, news and articles from INDI.",
    inputType: "email",
    inputPlaceholder: "Your Email",
    gifCinema: "https://media.giphy.com/media/l6mBchxYZc7Sw/giphy.gif",
    property1btnSubmitDesktopProps: property1btnSubmitDesktop3Data,
};

export const indiTablet768Data = {
    property1heroTabletProps: property1heroTabletData,
    filmGridTablet1Props: filmGridTablet1Data,
    filmGridTablet2Props: filmGridTablet2Data,
    property1containerPromoTabletProps: property1containerPromoTabletData,
};

