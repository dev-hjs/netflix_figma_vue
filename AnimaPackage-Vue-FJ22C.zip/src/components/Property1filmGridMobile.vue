<template>
  <div class="container-films-1">
    <div class="title-1 worksans-medium-white-16px">{{ title }}</div>
    <div class="flex-row">
      <div class="film-thumb-container">
        <film-thumb-mobile :src="filmThumbMobile1Props.src" />
        <film-thumb-mobile :src="filmThumbMobile2Props.src" :className="filmThumbMobile2Props.className" />
        <film-thumb-mobile :src="filmThumbMobile3Props.src" :className="filmThumbMobile3Props.className" />
        <film-thumb-mobile :src="filmThumbMobile4Props.src" :className="filmThumbMobile4Props.className" />
      </div>
      <div class="film-thumb-container-1">
        <film-thumb-mobile :src="filmThumbMobile5Props.src" :className="filmThumbMobile5Props.className" />
        <film-thumb-mobile :src="filmThumbMobile6Props.src" :className="filmThumbMobile6Props.className" />
        <film-thumb-mobile :src="filmThumbMobile7Props.src" :className="filmThumbMobile7Props.className" />
        <film-thumb-mobile :src="filmThumbMobile8Props.src" :className="filmThumbMobile8Props.className" />
      </div>
      <div class="film-thumb-container-1">
        <film-thumb-mobile :src="filmThumbMobile9Props.src" />
        <film-thumb-mobile :src="filmThumbMobile10Props.src" :className="filmThumbMobile10Props.className" />
        <film-thumb-mobile :src="filmThumbMobile11Props.src" :className="filmThumbMobile11Props.className" />
        <film-thumb-mobile :src="filmThumbMobile12Props.src" :className="filmThumbMobile12Props.className" />
      </div>
    </div>
  </div>
</template>

<script>
import FilmThumbMobile from "./FilmThumbMobile";
export default {
  name: "Property1filmGridMobile",
  components: {
    FilmThumbMobile,
  },
  props: [
    "title",
    "filmThumbMobile1Props",
    "filmThumbMobile2Props",
    "filmThumbMobile3Props",
    "filmThumbMobile4Props",
    "filmThumbMobile5Props",
    "filmThumbMobile6Props",
    "filmThumbMobile7Props",
    "filmThumbMobile8Props",
    "filmThumbMobile9Props",
    "filmThumbMobile10Props",
    "filmThumbMobile11Props",
    "filmThumbMobile12Props",
  ],
};
</script>

<style>
.container-films-1 {
  align-items: flex-start;
  align-self: center;
  display: flex;
  flex-direction: column;
  min-height: 706px;
  width: 323px;
}

.title-1 {
  letter-spacing: 0;
  line-height: 22px;
  margin-top: 38px;
  min-height: 49px;
  width: 323px;
}

.flex-row {
  align-items: flex-start;
  display: flex;
  height: 621px;
  min-width: 321px;
}

.film-thumb-container {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 621px;
  position: relative;
  width: 100px;
}

.film-thumb-container-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-left: 10px;
  min-height: 621px;
  position: relative;
  width: 100px;
}
</style>
