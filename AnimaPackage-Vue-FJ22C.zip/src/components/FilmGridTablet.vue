<template>
  <div class="container-films-1-3">
    <div class="title-5 worksans-medium-white-17px">{{ sectionTitle }}</div>
    <div class="row">
      <film-thumb-tablet :src="rowProps.src" />
      <film-thumb-tablet :src="rowProps2.src" :className="rowProps2.className" />
      <film-thumb-tablet :src="rowProps3.src" :className="rowProps3.className" />
      <film-thumb-tablet :src="rowProps4.src" :className="rowProps4.className" />
    </div>
    <div class="row-1">
      <film-thumb-tablet :src="rowProps5.src" />
      <film-thumb-tablet :src="rowProps6.src" :className="rowProps6.className" />
      <film-thumb-tablet :src="rowProps7.src" :className="rowProps7.className" />
      <film-thumb-tablet :src="rowProps8.src" :className="rowProps8.className" />
    </div>
    <div class="row-2">
      <film-thumb-tablet :src="rowProps9.src" :className="rowProps9.className" />
      <film-thumb-tablet :src="rowProps10.src" :className="rowProps10.className" />
      <film-thumb-tablet :src="rowProps11.src" :className="rowProps11.className" />
      <film-thumb-tablet :src="rowProps12.src" :className="rowProps12.className" />
    </div>
  </div>
</template>

<script>
import FilmThumbTablet from "./FilmThumbTablet";
export default {
  name: "FilmGridTablet",
  components: {
    FilmThumbTablet,
  },
  props: [
    "sectionTitle",
    "rowProps",
    "rowProps2",
    "rowProps3",
    "rowProps4",
    "rowProps5",
    "rowProps6",
    "rowProps7",
    "rowProps8",
    "rowProps9",
    "rowProps10",
    "rowProps11",
    "rowProps12",
  ],
};
</script>

<style>
.container-films-1-3 {
  align-items: flex-start;
  align-self: center;
  display: flex;
  flex-direction: column;
  margin-left: -32px;
  min-height: 762px;
  width: 606px;
}

.title-5 {
  letter-spacing: 0;
  line-height: 22px;
  margin-top: 59px;
  min-height: 49px;
  width: 606px;
}

.row,
.row-3 {
  align-items: flex-start;
  display: flex;
  height: 208px;
  min-width: 606px;
  position: relative;
}

.row-1,
.row-2,
.row-4,
.row-5 {
  align-items: flex-start;
  display: flex;
  height: 208px;
  margin-top: 15px;
  min-width: 606px;
  position: relative;
}
</style>
