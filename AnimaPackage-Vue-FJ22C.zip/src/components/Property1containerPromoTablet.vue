<template>
  <div class="container-promotion-2">
    <div class="stay-connected">
      <div class="stay-connected-text-1">
        <div class="title-6">{{ title }}</div>
        <p class="paragraph-2 worksans-light-white-11px" v-html="paragraph"></p>
      </div>
      <div class="stay-connected-form-1">
        <div class="email-input-2">
          <input
            class="your-email-1 worksans-normal-white-12px"
            name="youremail"
            :placeholder="inputPlaceholder"
            :type="inputType"
          />
          <div class="underline-2"></div>
        </div>
        <property1btn-submit-desktop :className="property1btnSubmitDesktopProps.className" />
      </div>
    </div>
    <div class="gif-cinema-1" :style="{ 'background-image': 'url(' + gifCinema + ')' }"></div>
  </div>
</template>

<script>
import Property1btnSubmitDesktop from "./Property1btnSubmitDesktop";
export default {
  name: "Property1containerPromoTablet",
  components: {
    Property1btnSubmitDesktop,
  },
  props: ["title", "paragraph", "inputType", "inputPlaceholder", "gifCinema", "property1btnSubmitDesktopProps"],
};
</script>

<style>
.container-promotion-2 {
  background-color: var(--cod-gray);
  display: flex;
  flex: 1;
  height: 270px;
  justify-content: flex-end;
  margin-left: 64px;
  max-height: 270px;
  z-index: 2;
}

.stay-connected {
  align-items: center;
  display: flex;
  flex: 1;
  flex-direction: column;
  height: 169px;
  margin-left: 33px;
  margin-right: 16px;
  margin-top: 37px;
  width: 371px;
}

.stay-connected-text-1 {
  display: flex;
  flex-direction: column;
  height: 132px;
  width: 371px;
}

.title-6 {
  color: var(--white);
  font-family: var(--font-family-work_sans);
  font-size: 30px;
  font-weight: 800;
  height: 44px;
  letter-spacing: 0;
  line-height: 25.3px;
}

.paragraph-2 {
  height: 72px;
  letter-spacing: 0;
  line-height: 22px;
  margin-top: 16px;
}

.stay-connected-form-1 {
  display: flex;
  margin-left: -68px;
  margin-top: 2px;
  position: relative;
  width: 303px;
}

.email-input-2 {
  display: flex;
  flex-direction: column;
  height: 35px;
  width: 211px;
}

.your-email-1 {
  background-color: transparent;
  border: 0;
  height: 34px;
  letter-spacing: 0;
  line-height: 19px;
  padding: 0;
  width: 209px;
}

.your-email-1::placeholder {
  color: #ffffff99;
}

.underline-2 {
  background-color: var(--white);
  height: 1px;
  width: 207.33px;
}

.gif-cinema-1 {
  background-position: 50% 50%;
  background-size: cover;
  width: 284px;
}

.gif-cinema-1 video {
  height: 100%;
  object-fit: cover;
  width: 100%;
}

.gif-cinema-1 img {
  object-fit: cover;
}
</style>
