<template>
  <div class="indi-tablet-768 screen">
    <div class="content-1">
      <property1hero-tablet
        :heroContainer="property1heroTabletProps.heroContainer"
        :title="property1heroTabletProps.title"
        :filmInfo="property1heroTabletProps.filmInfo"
        :filmAbout="property1heroTabletProps.filmAbout"
        :filmCredits="property1heroTabletProps.filmCredits"
        :property1btnWatchTabletProps="property1heroTabletProps.property1btnWatchTabletProps"
      />
      <film-grid-tablet v-bind="filmGridTablet1Props" />
      <film-grid-tablet v-bind="filmGridTablet2Props" />
    </div>
    <menu-tablet />
    <property1container-promo-tablet
      :title="property1containerPromoTabletProps.title"
      :paragraph="property1containerPromoTabletProps.paragraph"
      :inputType="property1containerPromoTabletProps.inputType"
      :inputPlaceholder="property1containerPromoTabletProps.inputPlaceholder"
      :gifCinema="property1containerPromoTabletProps.gifCinema"
      :property1btnSubmitDesktopProps="property1containerPromoTabletProps.property1btnSubmitDesktopProps"
    />
  </div>
</template>

<script>
import Property1heroTablet from "./Property1heroTablet";
import FilmGridTablet from "./FilmGridTablet";
import MenuTablet from "./MenuTablet";
import Property1containerPromoTablet from "./Property1containerPromoTablet";
export default {
  name: "IndiTablet768",
  components: {
    Property1heroTablet,
    FilmGridTablet,
    MenuTablet,
    Property1containerPromoTablet,
  },
  props: [
    "property1heroTabletProps",
    "filmGridTablet1Props",
    "filmGridTablet2Props",
    "property1containerPromoTabletProps",
  ],
};
</script>

<style>
.indi-tablet-768 {
  background-color: var(--log-cabin);
  display: flex;
  flex-direction: column;
  height: 100vh;
  justify-content: space-between;
  min-height: 2236px;
  min-width: 768px;
  position: relative;
  width: 100%;
}

.content-1 {
  display: flex;
  flex: 1;
  flex-direction: column;
  height: 1889px;
  margin-left: 64px;
  max-height: 1889px;
  position: relative;
  z-index: 1;
}
</style>
