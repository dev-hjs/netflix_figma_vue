<template>
  <div class="sidebar-menu-2">
    <img
      class="indi-logo-2"
      src="https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/indi-logo-2@2x.png"
    />
    <icon-tablet iconId="1" />
    <icon-tablet iconId="2" className="menu-ico-tablet-1" />
    <icon-tablet iconId="3" className="menu-ico-tablet-2" />
    <icon-tablet iconId="4" />
  </div>
</template>

<script>
import IconTablet from "./IconTablet";
export default {
  name: "MenuTablet",
  components: {
    IconTablet,
  },
};
</script>

<style>
.sidebar-menu-2 {
  align-items: center;
  background-color: var(--licorice);
  display: flex;
  flex-direction: column;
  height: 100%;
  left: 0;
  position: fixed;
  top: 0;
  width: 64px;
  z-index: 3;
}

.indi-logo-2 {
  height: 25px;
  margin-left: 1px;
  margin-top: 19px;
  width: 31px;
}
</style>
