<template>
  <div class="container-promotion" :style="{ 'background-image': 'url(' + containerPromotion + ')' }">
    <div class="title-2">{{ title }}</div>
    <p class="paragraph worksans-light-white-10px" v-html="paragraph"></p>
    <div class="email-input">
      <input
        class="your-email worksans-normal-white-10px"
        name="youremail"
        :placeholder="inputPlaceholder"
        :type="inputType"
      />
      <div class="underline"></div>
    </div>
    <property1btn-submit-desktop />
  </div>
</template>

<script>
import Property1btnSubmitDesktop from "./Property1btnSubmitDesktop";
export default {
  name: "Property1containerPromoMobile",
  components: {
    Property1btnSubmitDesktop,
  },
  props: ["containerPromotion", "title", "paragraph", "inputType", "inputPlaceholder"],
};
</script>

<style>
.container-promotion {
  align-items: center;
  background-position: 50% 50%;
  background-size: cover;
  display: flex;
  flex: 1;
  flex-direction: column;
  margin-top: 92px;
  max-height: 305px;
  position: relative;
}

.title-2 {
  color: var(--white);
  font-family: var(--font-family-work_sans);
  font-size: 25px;
  font-weight: 800;
  height: 44px;
  letter-spacing: 0;
  line-height: 25.3px;
  margin-left: 21px;
  margin-top: 37px;
  width: 342px;
}

.paragraph {
  height: 72px;
  letter-spacing: 0;
  line-height: 18px;
  margin-left: -88px;
  margin-top: 6px;
  width: 233px;
}

.email-input {
  align-items: center;
  display: flex;
  flex-direction: column;
  height: 35px;
  margin-left: -110px;
  margin-top: 18px;
  width: 211px;
}

.your-email {
  background-color: transparent;
  border: 0;
  height: 34px;
  letter-spacing: 0;
  line-height: 15px;
  margin-left: -2px;
  padding: 0;
  width: 209px;
}

.your-email::placeholder {
  color: #ffffff99;
}

.underline {
  background-color: var(--white);
  height: 1px;
  margin-left: -3.7px;
  width: 207.33px;
}
</style>
