<template>
  <div :class="[`menu-ico-desktop-1`, className || ``]">
    <div class="search-icon valign-text-middle icons-pack-regular-normal-white-17px">{{ iconId }}</div>
  </div>
</template>

<script>
export default {
  name: "IconLarge",
  props: ["iconId", "className"],
};
</script>

<style>
.menu-ico-desktop-1 {
  display: flex;
  height: 41px;
  margin-top: 25.5px;
  width: 41px;
}

.search-icon {
  cursor: pointer;
  height: 17px;
  letter-spacing: 0;
  margin-left: 11px;
  margin-top: 12px;
  text-align: center;
  transition: all 0.2s ease;
  width: 18px;
}

.search-icon:hover {
  color: #ff4e4e;
}

.menu-ico-desktop-1.menu-ico-desktop-2 {
  margin-top: 26px;
}

.menu-ico-desktop-1.menu-ico-desktop {
  margin-top: 27px;
}
</style>
