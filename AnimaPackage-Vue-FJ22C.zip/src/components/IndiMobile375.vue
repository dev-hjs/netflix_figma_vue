<template>
  <div class="full-project screen">
    <div class="content">
      <div class="main-content">
        <property1hero-mobile
          :filmPreview="property1heroMobileProps.filmPreview"
          :indiLogo="property1heroMobileProps.indiLogo"
          :title="property1heroMobileProps.title"
          :filmInfo="property1heroMobileProps.filmInfo"
          :filmAbout="property1heroMobileProps.filmAbout"
          :filmCredits="property1heroMobileProps.filmCredits"
          :property1btnWatchMobileProps="property1heroMobileProps.property1btnWatchMobileProps"
        />
        <property1film-grid-mobile v-bind="property1filmGridMobile1Props" />
        <property1film-grid-mobile v-bind="property1filmGridMobile2Props" />
      </div>
      <property1container-promo-mobile
        :containerPromotion="property1containerPromoMobileProps.containerPromotion"
        :title="property1containerPromoMobileProps.title"
        :paragraph="property1containerPromoMobileProps.paragraph"
        :inputType="property1containerPromoMobileProps.inputType"
        :inputPlaceholder="property1containerPromoMobileProps.inputPlaceholder"
      />
    </div>
    <menu-mobile />
  </div>
</template>

<script>
import Property1heroMobile from "./Property1heroMobile";
import Property1filmGridMobile from "./Property1filmGridMobile";
import Property1containerPromoMobile from "./Property1containerPromoMobile";
import MenuMobile from "./MenuMobile";
export default {
  name: "IndiMobile375",
  components: {
    Property1heroMobile,
    Property1filmGridMobile,
    Property1containerPromoMobile,
    MenuMobile,
  },
  props: [
    "property1heroMobileProps",
    "property1filmGridMobile1Props",
    "property1filmGridMobile2Props",
    "property1containerPromoMobileProps",
  ],
};
</script>

<style>
.full-project {
  background-color: var(--log-cabin);
  display: flex;
  height: 100vh;
  min-height: 2396px;
  min-width: 375px;
  position: relative;
  width: 100%;
}

.content {
  display: flex;
  flex: 1;
  flex-direction: column;
  height: 2343px;
  position: relative;
  z-index: 1;
}

.main-content {
  display: flex;
  flex: 1;
  flex-direction: column;
  max-height: 1946px;
  position: relative;
}
</style>
