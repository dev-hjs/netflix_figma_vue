<template>
  <div class="sidebar-menu">
    <div class="bottom-menu-icons">
      <icon-small iconId="1" />
      <icon-small iconId="2" className="menu-ico-mobile-1" />
      <icon-small iconId="3" className="menu-ico-mobile-2" />
      <icon-small iconId="4" className="menu-ico-mobile-3" />
    </div>
  </div>
</template>

<script>
import IconSmall from "./IconSmall";
export default {
  name: "MenuMobile",
  components: {
    IconSmall,
  },
};
</script>

<style>
.sidebar-menu {
  align-items: center;
  background-color: var(--licorice);
  bottom: 0;
  display: flex;
  height: 53px;
  justify-content: center;
  left: 0;
  position: fixed;
  width: 100%;
  z-index: 2;
}

.bottom-menu-icons {
  display: flex;
  height: 40px;
  margin-top: -1px;
  position: relative;
  width: 323px;
}
</style>
