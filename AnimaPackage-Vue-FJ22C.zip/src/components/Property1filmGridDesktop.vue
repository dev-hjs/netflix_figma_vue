<template>
  <div :class="[`container-films-1-1`, className || ``]">
    <div class="section-title worksans-medium-white-20px">{{ sectionTitle }}</div>
    <div class="flex-row-1">
      <div class="film-thumb-container-2">
        <film-thumb-desktop :src="filmThumbDesktop1Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop2Props.src" :className="filmThumbDesktop2Props.className" />
      </div>
      <div class="film-thumb-container-3">
        <film-thumb-desktop :src="filmThumbDesktop3Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop4Props.src" :className="filmThumbDesktop4Props.className" />
      </div>
      <div class="film-thumb-container-3">
        <film-thumb-desktop :src="filmThumbDesktop5Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop6Props.src" :className="filmThumbDesktop6Props.className" />
      </div>
      <div class="film-thumb-container-3">
        <film-thumb-desktop :src="filmThumbDesktop7Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop8Props.src" :className="filmThumbDesktop8Props.className" />
      </div>
      <div class="film-thumb-container-3">
        <film-thumb-desktop :src="filmThumbDesktop9Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop10Props.src" :className="filmThumbDesktop10Props.className" />
      </div>
      <div class="film-thumb-container-4">
        <film-thumb-desktop :src="filmThumbDesktop11Props.src" />
        <film-thumb-desktop :src="filmThumbDesktop12Props.src" :className="filmThumbDesktop12Props.className" />
      </div>
    </div>
  </div>
</template>

<script>
import FilmThumbDesktop from "./FilmThumbDesktop";
export default {
  name: "Property1filmGridDesktop",
  components: {
    FilmThumbDesktop,
  },
  props: [
    "sectionTitle",
    "className",
    "filmThumbDesktop1Props",
    "filmThumbDesktop2Props",
    "filmThumbDesktop3Props",
    "filmThumbDesktop4Props",
    "filmThumbDesktop5Props",
    "filmThumbDesktop6Props",
    "filmThumbDesktop7Props",
    "filmThumbDesktop8Props",
    "filmThumbDesktop9Props",
    "filmThumbDesktop10Props",
    "filmThumbDesktop11Props",
    "filmThumbDesktop12Props",
  ],
};
</script>

<style>
.container-films-1-1 {
  align-items: flex-start;
  display: flex;
  flex: 1;
  flex-direction: column;
  margin-left: 49px;
  margin-right: 50px;
  max-height: 715px;
  min-height: 715px;
  padding: 0.5px 0;
}

.section-title {
  letter-spacing: 0;
  line-height: 22px;
  margin-top: 80px;
  min-height: 58px;
  width: 1232px;
}

.flex-row-1 {
  align-items: flex-start;
  display: flex;
  height: 575px;
  min-width: 1231px;
}

.film-thumb-container-2 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 575px;
  position: relative;
  width: 190px;
}

.film-thumb-container-3 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-left: 18px;
  min-height: 575px;
  position: relative;
  width: 190px;
}

.film-thumb-container-4 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-left: 19px;
  min-height: 575px;
  position: relative;
  width: 190px;
}

.container-films-1-1.container-films-1-2 {
  margin-left: 48px;
  margin-right: 51px;
}
</style>
