<template>
  <div class="sidebar-menu-1">
    <img
      class="indi-logo-1"
      src="https://anima-uploads.s3.amazonaws.com/projects/6165b3e879c1baabe259dd1f/releases/6239bb1d36ba6a8f50b22449/img/indi-logo-1@2x.png"
    />
    <icon-large iconId="1" />
    <icon-large iconId="2" className="menu-ico-desktop-2" />
    <icon-large iconId="3" className="menu-ico-desktop" />
    <icon-large iconId="4" className="menu-ico-desktop" />
  </div>
</template>

<script>
import IconLarge from "./IconLarge";
export default {
  name: "MenuDesktop",
  components: {
    IconLarge,
  },
};
</script>

<style>
.sidebar-menu-1 {
  align-items: center;
  background-color: var(--licorice);
  display: flex;
  flex-direction: column;
  height: 100%;
  left: 0;
  position: fixed;
  top: 0;
  width: 109px;
  z-index: 3;
}

.indi-logo-1 {
  height: 31.49px;
  margin-left: -1.5px;
  margin-top: 30px;
  width: 39.59px;
}
</style>
