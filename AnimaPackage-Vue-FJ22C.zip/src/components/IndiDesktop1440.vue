<template>
  <div class="indi-desktop-1440 screen">
    <div class="group-7">
      <property1hero-desktop
        :heroContainer="property1heroDesktopProps.heroContainer"
        :mainTitle="property1heroDesktopProps.mainTitle"
        :filmInfo="property1heroDesktopProps.filmInfo"
        :filmAbout="property1heroDesktopProps.filmAbout"
        :filmCredits="property1heroDesktopProps.filmCredits"
        :property1btnWatchDesktopProps="property1heroDesktopProps.property1btnWatchDesktopProps"
      />
      <property1film-grid-desktop v-bind="property1filmGridDesktop1Props" />
      <property1film-grid-desktop v-bind="property1filmGridDesktop2Props" />
    </div>
    <menu-desktop />
    <property1container-promo-desktop
      :title="property1containerPromoDesktopProps.title"
      :paragraph="property1containerPromoDesktopProps.paragraph"
      :inputType="property1containerPromoDesktopProps.inputType"
      :inputPlaceholder="property1containerPromoDesktopProps.inputPlaceholder"
      :gifCinema="property1containerPromoDesktopProps.gifCinema"
      :property1btnSubmitDesktopProps="property1containerPromoDesktopProps.property1btnSubmitDesktopProps"
    />
  </div>
</template>

<script>
import Property1heroDesktop from "./Property1heroDesktop";
import Property1filmGridDesktop from "./Property1filmGridDesktop";
import MenuDesktop from "./MenuDesktop";
import Property1containerPromoDesktop from "./Property1containerPromoDesktop";
export default {
  name: "IndiDesktop1440",
  components: {
    Property1heroDesktop,
    Property1filmGridDesktop,
    MenuDesktop,
    Property1containerPromoDesktop,
  },
  props: [
    "property1heroDesktopProps",
    "property1filmGridDesktop1Props",
    "property1filmGridDesktop2Props",
    "property1containerPromoDesktopProps",
  ],
};
</script>

<style>
.indi-desktop-1440 {
  background-color: var(--log-cabin);
  display: flex;
  flex-direction: column;
  height: 100vh;
  justify-content: space-between;
  min-height: 2492px;
  min-width: 1440px;
  position: relative;
  width: 100%;
}

.group-7 {
  display: flex;
  flex: 1;
  flex-direction: column;
  height: 1974px;
  margin-left: 109px;
  max-height: 1974px;
  position: relative;
  z-index: 2;
}
</style>
