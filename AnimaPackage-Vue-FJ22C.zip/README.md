# Anima App exported vue code
This package was generated automatically with [Anima App](https://www.animaapp.com).
## Instructions
```
cd package_code
npm install
npm start
```
Open [http://localhost:8080](http://localhost:8080).